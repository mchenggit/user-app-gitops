Example of migrating 0.9.1 release of pipeline for cp4apps 4.3
